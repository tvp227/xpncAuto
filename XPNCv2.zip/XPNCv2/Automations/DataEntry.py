import openpyxl
import os
import getpass
from datetime import datetime

username = getpass. getuser()

# Load the Excel file
wb = openpyxl.load_workbook(f'C:/Users/{username}/Documents\XPNCv2/expenses.xlsx')

# Select the first sheet
sheet = wb.active

# Set the starting row for entries
start_row = 5

# Find the next empty row in column A
next_row = start_row

# Prompt for adding an entry
add_another = "yes"
while add_another.lower() == "yes":
    # Prompt for inputs
    date = input("Enter the date: ")
    description = input("Enter the description: ")
    reason = input("Enter the reason (including customer name): ")
    receipt = input("Do you have a receipt? ")
    cost = input("Enter the cost: ")
    quantity = input("Enter the quantity: ")

    # Fill in the values in separate cells across rows in column A
    sheet.cell(row=next_row, column=1).value = date
    sheet.cell(row=next_row, column=2).value = description
    sheet.cell(row=next_row, column=3).value = reason
    sheet.cell(row=next_row, column=4).value = receipt
    sheet.cell(row=next_row, column=5).value = cost
    sheet.cell(row=next_row, column=6).value = quantity

    next_row += 1

    # Prompt for adding another entry
    add_another = input("Do you want to add another entry? (yes/no): ")

# Add the current date and time to cell I2
current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
sheet.cell(row=2, column=9).value = current_datetime

# Save the changes
wb.save(f'C:/Users/{username}/Documents/XPNCv2/expenses.xlsx')