Expense from automator.


To use the automator ensure that the XpncAuto folder is within your ./Documents file directory.

Run the script within python and you will be prompt to select a directory, this will convert all available pictures in this directory into a pdf. Ensure only receipts are in the folder.

You will then be asked a series of questions that will automatically fill out an excel template attached.

When complete you can add both files as attachments and send accordingly.


